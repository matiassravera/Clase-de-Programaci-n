#include <stdio.h>
#include <stdlib.h>
#include "utn.h"

int main()
{
    printf("Hello world!\n");
    //utn_getCaracter()
    return 0;
}
